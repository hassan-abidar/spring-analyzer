package com.shanks.model;

public class Payment {
}
