package com.shanks.response;


import lombok.Data;

@Data

public class MessageResponse {

    private String message;

}
