package com.shanks.model;

import lombok.Data;

@Data

public class ContactInformation {

    private String email;
    private String mobile;
    private String facebook;
    private String instagram;
}
