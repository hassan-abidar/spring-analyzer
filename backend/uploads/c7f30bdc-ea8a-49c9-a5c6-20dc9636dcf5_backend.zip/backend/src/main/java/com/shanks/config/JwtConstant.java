package com.shanks.config;

public class JwtConstant {

    public static final String SECRET_KEY = "zxfxtyfdxtzvdtyzgcxngamlaihuhdaygyagbdhgydgabdua1234vhghab8646bvgv";
    public static final String JWT_HEADER = "Authorization";
}
