package com.shanks.model;

public enum ROLE {
    ADMIN,
    CUSTOMER,
    OWNER,
}
