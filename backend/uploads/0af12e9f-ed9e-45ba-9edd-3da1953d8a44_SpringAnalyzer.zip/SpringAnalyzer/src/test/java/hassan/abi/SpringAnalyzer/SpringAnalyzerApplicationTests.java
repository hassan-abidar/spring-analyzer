package hassan.abi.SpringAnalyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
